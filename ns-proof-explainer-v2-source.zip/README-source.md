# ns-proof-explainer-v2 source

This directory contains the reproducible source for the 94-second, silent,
1280x720 motion-graphics explainer.

## Build

Requirements: Python 3.10+, Pillow, FFmpeg, and DejaVu Sans fonts.

```bash
python3 -m pip install -r requirements.txt
python3 generate_video.py
```

The script writes `ns-proof-explainer-v2.mp4` to the parent directory.

The animation is an educational map of the argument. It is not a substitute
for the complete paper or independent mathematical verification.
