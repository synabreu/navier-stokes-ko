#!/usr/bin/env python3
"""Generate ns-proof-explainer-v2.mp4 with Pillow and FFmpeg.

The animation is intentionally self-contained: no network, browser, or external
assets are required. It presents a visual roadmap of the proof rather than
claiming that a short video substitutes for the full paper.
"""

from __future__ import annotations

import math
import subprocess
from dataclasses import dataclass
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


WIDTH, HEIGHT = 1280, 720
FPS = 24
DURATION = 94
BG = (6, 11, 25)
WHITE = (239, 245, 255)
MUTED = (158, 174, 203)
CYAN = (72, 211, 255)
BLUE = (78, 121, 255)
VIOLET = (167, 116, 255)
ORANGE = (255, 169, 76)
RED = (255, 92, 119)
GREEN = (80, 222, 169)


def font(size: int, bold: bool = False):
    name = "DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf"
    return ImageFont.truetype(f"/usr/share/fonts/truetype/dejavu/{name}", size)


F_TITLE = font(52, True)
F_HEAD = font(34, True)
F_BODY = font(24)
F_SMALL = font(18)
F_MATH = font(29)


@dataclass(frozen=True)
class Scene:
    start: float
    end: float
    label: str


SCENES = [
    Scene(0, 8, "THE QUESTION"),
    Scene(8, 19, "THE EQUATIONS"),
    Scene(19, 31, "VORTICITY"),
    Scene(31, 44, "MULTI-SCALE PULSES"),
    Scene(44, 57, "THE CASCADE"),
    Scene(57, 70, "CONTROL THE ERRORS"),
    Scene(70, 82, "FORMAL PROOF MAP"),
    Scene(82, 94, "WHAT THIS VIDEO PROVES"),
]


def ease(x: float) -> float:
    x = max(0.0, min(1.0, x))
    return x * x * (3 - 2 * x)


def alpha_in(t: float, start: float, duration: float = 0.8) -> float:
    return ease((t - start) / duration)


def mix(a, b, s):
    return tuple(int(x + (y - x) * s) for x, y in zip(a, b))


def glow_circle(draw, xy, radius, color, width=3):
    x, y = xy
    for k in range(5, 0, -1):
        c = mix(BG, color, 0.08 * k)
        draw.ellipse((x-radius-k*3, y-radius-k*3, x+radius+k*3, y+radius+k*3), outline=c, width=2)
    draw.ellipse((x-radius, y-radius, x+radius, y+radius), outline=color, width=width)


def text(draw, pos, value, fnt, fill=WHITE, anchor="la"):
    draw.text(pos, value, font=fnt, fill=fill, anchor=anchor)


def multiline(draw, pos, lines, alpha=1.0, color=WHITE, gap=38):
    x, y = pos
    fill = mix(BG, color, alpha)
    for i, line in enumerate(lines):
        text(draw, (x, y + i * gap), line, F_BODY, fill)


def base_frame(t: float):
    im = Image.new("RGB", (WIDTH, HEIGHT), BG)
    d = ImageDraw.Draw(im)
    # Subtle technical grid.
    grid = (15, 29, 53)
    for x in range(0, WIDTH, 64):
        d.line((x, 0, x, HEIGHT), fill=grid, width=1)
    for y in range(0, HEIGHT, 64):
        d.line((0, y, WIDTH, y), fill=grid, width=1)
    # Header and timeline.
    text(d, (48, 36), "NAVIER-STOKES / PROOF ROADMAP", F_SMALL, CYAN)
    d.line((48, 68, WIDTH - 48, 68), fill=(38, 58, 88), width=2)
    p = min(1.0, t / DURATION)
    d.rounded_rectangle((48, HEIGHT-25, WIDTH-48, HEIGHT-17), 4, fill=(28, 44, 70))
    d.rounded_rectangle((48, HEIGHT-25, 48 + int((WIDTH-96)*p), HEIGHT-17), 4, fill=CYAN)
    return im, d


def title_scene(d, t):
    a = alpha_in(t, 0.3)
    text(d, (WIDTH/2, 245), "Can a smooth 3D flow", F_TITLE, mix(BG, WHITE, a), "ma")
    text(d, (WIDTH/2, 315), "form a finite-time singularity?", F_TITLE, mix(BG, CYAN, a), "ma")
    text(d, (WIDTH/2, 412), "A visual roadmap of the claimed construction", F_BODY, mix(BG, MUTED, alpha_in(t, 1.5)), "ma")
    # Converging rings.
    s = ease(t / 8)
    for i in range(5):
        r = 72 - i*11 - 18*s
        color = mix(BLUE, RED, s)
        d.ellipse((WIDTH-180-r, 500-r, WIDTH-180+r, 500+r), outline=color, width=3)


def equation_scene(d, t):
    a = alpha_in(t, 8.2)
    text(d, (64, 118), "1. Start with the incompressible equations", F_HEAD, mix(BG, WHITE, a))
    d.rounded_rectangle((70, 205, 775, 430), 24, fill=(12, 23, 44), outline=(52, 84, 128), width=2)
    text(d, (420, 282), "du/dt + (u . grad)u = -grad p + nu Delta u", F_MATH, CYAN, "ma")
    text(d, (420, 350), "div u = 0", F_MATH, WHITE, "ma")
    multiline(d, (850, 210), ["Smooth initial data", "must stay smooth", "for all future time...", "or a blow-up must exist."], alpha_in(t, 10), MUTED, 55)
    # Streamlines.
    phase = (t-8)*1.3
    for j in range(8):
        pts=[]
        for x in range(70, 760, 12):
            y=520+j*16+12*math.sin(x/85+phase+j*.4)
            pts.append((x,y))
        d.line(pts, fill=mix(BLUE,CYAN,j/8), width=2)


def vorticity_scene(d, t):
    text(d, (64, 118), "2. Follow vorticity, where stretching amplifies rotation", F_HEAD, WHITE)
    cx, cy = 365, 390
    q = ease((t-19)/12)
    for i in range(13):
        ang = i*2*math.pi/13 + (t-19)*0.35
        rr = 175 - 95*q + 10*math.sin(i*1.7)
        x = cx + rr*math.cos(ang)
        y = cy + .48*rr*math.sin(ang)
        glow_circle(d, (x,y), 7, mix(CYAN,RED,q), 2)
    d.ellipse((cx-190,cy-92,cx+190,cy+92), outline=(64,96,142), width=2)
    text(d, (830, 230), "omega = curl u", F_MATH, CYAN, "ma")
    text(d, (830, 300), "vortex stretching", F_BODY, ORANGE, "ma")
    d.line((830,335,830,505),fill=(49,73,111),width=6)
    d.line((830,505-int(150*q),830,505),fill=RED,width=6)
    text(d, (830, 548), "concentration increases", F_SMALL, MUTED, "ma")


def pulses_scene(d, t):
    text(d, (64, 118), "3. Build localized pulses at separated scales", F_HEAD, WHITE)
    q = ease((t-31)/13)
    centers=[]
    for i in range(7):
        x=130+i*160
        y=370+55*math.sin(i*.8)
        centers.append((x,y))
        r=58*(0.82**i)*(1-.18*q)
        d.ellipse((x-r*1.7,y-r*.6,x+r*1.7,y+r*.6),outline=mix(BLUE,VIOLET,i/6),width=4)
        d.ellipse((x-r*.45,y-r*.45,x+r*.45,y+r*.45),fill=mix(CYAN,RED,i/6))
        text(d,(x,520),f"scale {i+1}",F_SMALL,MUTED,"ma")
    for a,b in zip(centers,centers[1:]):
        d.line((a[0]+65,a[1],b[0]-65,b[1]),fill=(67,92,135),width=3)
        d.polygon([(b[0]-65,b[1]),(b[0]-79,b[1]-7),(b[0]-79,b[1]+7)],fill=CYAN)
    text(d,(WIDTH/2,620),"Each pulse is smaller, faster, and timed to feed the next.",F_BODY,WHITE,"ma")


def cascade_scene(d, t):
    text(d, (64, 118), "4. Arrange a finite-time cascade", F_HEAD, WHITE)
    q=(t-44)/13
    x0,y0=160,560
    pts=[]
    for i in range(9):
        x=x0+i*112
        y=y0-44*i-4*i*i
        pts.append((x,y))
    d.line(pts,fill=(57,82,122),width=4)
    active=min(8,int(max(0,q)*9))
    for i,(x,y) in enumerate(pts):
        c=RED if i<=active else (47,67,101)
        glow_circle(d,(x,y),18 if i==active else 11,c,3)
        text(d,(x,y+42),f"t{i}",F_SMALL,MUTED,"ma")
    text(d,(870,565),"t0 < t1 < ... < t*",F_MATH,CYAN,"ma")
    text(d,(870,610),"infinitely many stages; finite total time",F_SMALL,MUTED,"ma")


def estimates_scene(d, t):
    text(d, (64, 118), "5. Prove the intended effect dominates every error", F_HEAD, WHITE)
    q=ease((t-57)/13)
    rows=[("main amplification",GREEN,.92),("transport error",ORANGE,.34),("viscous error",BLUE,.27),("interaction tails",VIOLET,.20)]
    for i,(name,c,v) in enumerate(rows):
        y=220+i*92
        text(d,(90,y),name,F_BODY,WHITE)
        d.rounded_rectangle((365,y-5,1110,y+27),12,fill=(24,39,64))
        d.rounded_rectangle((365,y-5,365+int(745*v*q),y+27),12,fill=c)
        text(d,(1140,y+10),f"{v:.2f}",F_SMALL,c,"lm")
    text(d,(WIDTH/2,635),"The proof closes only if the inequalities hold at every scale.",F_BODY,CYAN,"ma")


def map_scene(d, t):
    text(d, (64, 118), "6. Convert the construction into a checkable proof chain", F_HEAD, WHITE)
    labels=["initial data","pulse lemma","induction","error bounds","blow-up"]
    colors=[BLUE,CYAN,VIOLET,ORANGE,RED]
    q=ease((t-70)/12)
    for i,(lab,c) in enumerate(zip(labels,colors)):
        x=82+i*238
        y=315 if i%2==0 else 430
        d.rounded_rectangle((x,y,x+190,y+72),18,fill=(13,27,50),outline=c,width=3)
        text(d,(x+95,y+36),lab,F_SMALL,WHITE,"mm")
        if i<4:
            nx=82+(i+1)*238
            ny=315 if (i+1)%2==0 else 430
            d.line((x+190,y+36,nx,ny+36),fill=mix((45,65,98),CYAN,q),width=3)
    text(d,(WIDTH/2,595),"Formal verification checks the logic; it does not replace expert review.",F_BODY,MUTED,"ma")


def limits_scene(d, t):
    text(d, (64, 118), "What this 94-second video does -- and does not -- establish", F_HEAD, WHITE)
    d.rounded_rectangle((70,205,585,585),24,fill=(11,31,35),outline=GREEN,width=2)
    d.rounded_rectangle((695,205,1210,585),24,fill=(35,17,31),outline=RED,width=2)
    text(d,(327,255),"IT DOES",F_HEAD,GREEN,"ma")
    text(d,(952,255),"IT DOES NOT",F_HEAD,RED,"ma")
    multiline(d,(115,325),["show the proof architecture", "visualize the scale cascade", "identify the estimate bottleneck", "link to the full source"],alpha_in(t,82.5),WHITE,58)
    multiline(d,(740,325),["reproduce 166 pages", "settle independent review", "replace the original paper", "certify prize acceptance"],alpha_in(t,82.5),WHITE,58)
    text(d,(WIDTH/2,645),"Read the paper and notes before treating any claim as established.",F_BODY,CYAN,"ma")


def render(t: float):
    im,d=base_frame(t)
    if t<8: title_scene(d,t)
    elif t<19: equation_scene(d,t)
    elif t<31: vorticity_scene(d,t)
    elif t<44: pulses_scene(d,t)
    elif t<57: cascade_scene(d,t)
    elif t<70: estimates_scene(d,t)
    elif t<82: map_scene(d,t)
    else: limits_scene(d,t)
    return im


def main():
    out=Path(__file__).resolve().parent.parent/"ns-proof-explainer-v2.mp4"
    cmd=["ffmpeg","-y","-f","rawvideo","-pix_fmt","rgb24","-s",f"{WIDTH}x{HEIGHT}","-r",str(FPS),"-i","-","-an","-c:v","libx264","-preset","medium","-crf","27","-pix_fmt","yuv420p","-movflags","+faststart",str(out)]
    p=subprocess.Popen(cmd,stdin=subprocess.PIPE)
    try:
        for n in range(FPS*DURATION):
            p.stdin.write(render(n/FPS).tobytes())
    finally:
        if p.stdin:
            p.stdin.close()
    if p.wait()!=0:
        raise SystemExit("ffmpeg failed")
    print(out)


if __name__ == "__main__":
    main()
